# origin-xps-figure — 用 Origin 画出版级 XPS 图（DeepSeek Harness 技能）

一个可直接安装到 **DeepSeek Harness** 的技能包：把 XPS 窄扫谱（含峰拟合结果）用 Origin
画成出版级图片——多循环堆叠瀑布图、单谱分峰图，包含分峰填充、真透明度、轴刻度与字体等
全部实测通过的设置，**不需要试错**。

## 安装（两种方式）

**方式 A：作为仓库级技能（推荐）**

把本压缩包解压到项目根目录，使路径变成：

```
<你的项目>/.agents/skills/origin-xps-figure/SKILL.md
```

重启/刷新 DeepSeek Harness 会话后，技能列表里会出现 `origin-xps-figure`。

**方式 B：直接让 Harness 读**

把压缩包整个发给 DeepSeek Harness，说：

> 读一下这个压缩包里的 SKILL.md，按它的方式帮我画 XPS 图。

## 技能里有什么

| 内容 | 说明 |
|---|---|
| `SKILL.md` | 核心：**一次就对的属性清单**、无效属性/坑、完整流程、验证清单 |
| `assets/prep.py` | 多循环：解析 CasaXPS 导出的窄扫 CSV → 宽表 + `meta.json` |
| `assets/Make-XpsStacked.ps1` | 建图主脚本（布局/样式/填充/透明度/轴/导出，全参数化） |
| `assets/Build-Stacked.ps1` | 堆叠瀑布图一键驱动（读 meta.json，逐个元素出图） |
| `assets/prep_single.py` | 单谱：从源 CSV 取**一个循环** → 单循环宽表 + `meta_single.json` |
| `assets/Build-Single.ps1` | 单谱分峰图一键驱动（4.5 × 3.7 in → `XPS_<元素>_fit.png`） |
| `assets/Layer-Composite.ps1` + `assets/composite_layers.py` | 透明度备用方案（分层渲染 + alpha 合成） |
| `assets/SAMPLE_FORMAT.md` | 输入格式与 `meta.json` / `meta_single.json` 字段说明 |

## 需要什么环境

- **OriginPro 2023+**（Windows），能通过 COM 连接（`Origin.ApplicationSI`）
- **PowerShell 7**（`pwsh`）
- **Python 3**（含 numpy + Pillow；DeepSeek Harness 自带的运行时即可）
- 可选：`OriginToolkit.ps1`（若使用 Harness 内置 Origin 工具链会自动提供；
  否则把 `Get-OriginApp` 之类的封装按 `SKILL.md` 里的 COM 调用自行替换）

## 5 分钟上手

### 多循环堆叠瀑布图

```powershell
# 1) 准备数据：把 CasaXPS 导出的窄扫 CSV 放进 data_raw\
# 2) 改 assets\prep.py 顶部的 JOBS（文件名、元素名、显示窗口、基线模式）
$env:PYTHONUTF8 = 1
python .\assets\prep.py                       # → data\meta.json
.\assets\Build-Stacked.ps1 -OutDir .\out      # → out\XPS_<元素>_stacked.png
```

### 单谱分峰图

```powershell
# 同一份源 CSV，挑一个循环（--cycle 从 0 开始）
python .\assets\prep_single.py --file YOUR.csv --elem "C 1s" --cycle 2 `
    --window 281.5 291.5 --mode bgsub --id s1     # → data\meta_single.json
.\assets\Build-Single.ps1 -OutDir .\out            # → out\XPS_C1s_fit.png
```

单谱图默认扣背景（基线为 0，填充紧贴基线，最像文献里的单谱分峰图）；
想要"填充下沿跟着真实弯曲背景走"就用 `--mode raw`。

输出默认 **600 dpi**、透明分峰填充、蓝→红顺序配色、Arial 刻度。

## 样式一览（技能默认值）

- 页面 1.75 × 10 in（窄长条），单谱可改 4.5 × 3.7 in
- 边框四边统一（`thickness = 3` ≈ 8 px @300 dpi）
- X 轴：3 个整数刻度，Arial 粗体 13 pt，朝内
- Y 轴：无刻度无数字，标题 `Intensity (a.u.)`
- 分峰：按结合能**蓝→红顺序渐变**，填充到各自的背景曲线，**30% 透明**
- 实测点：黑色空心圆，**50% 透明**
- 背景：浅灰实线；包络：深灰细线
- 框内不放任何文字（循环顺序看图注）

## 核心坑（详见 SKILL.md）

- 刻度数目不要用 `layer.x.inc` / `majorTicks`（前者本机不渲染、后者只能近似）→ 用 **`layer.x.ticksbydata$`**
- 填充范围靠 **绘图顺序**：`峰, 背景, 峰, 背景…` + `-pfv 8`
- 透明度百分比只能走 **COM**：`DataPlot.SetNumProp('Transparency', n)`；LabTalk 的 `-paaf` 只是开关
- 文本对象的字体要用 `label.font`（`-f` 无效），字号要用 `\p<百分比>`（`.pt` 无效）
- `layer.plot` 不是曲线数，用 `doc -e DY` 数

## 许可

MIT。示例中不含任何实验数据。
